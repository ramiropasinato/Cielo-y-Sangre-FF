using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

// Crea una transición retro de franjas sin necesitar configurar objetos en las escenas.
public class TransicionRetro : MonoBehaviour
{
    private static TransicionRetro instancia;

    [Header("Aspecto de la transición")]
    [SerializeField] private int cantidadFranjas = 10;
    [SerializeField] private float duracionFranja = 0.035f;
    [SerializeField] private float pausaEntreFranjas = 0.012f;

    private RectTransform[] franjas;
    private bool transicionando;

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
    private static void ReiniciarEstatica()
    {
        instancia = null;
    }

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
    private static void CrearGestor()
    {
        if (instancia != null) return;

        GameObject objeto = new GameObject("TransicionRetro");
        objeto.AddComponent<TransicionRetro>();
    }

    private void Awake()
    {
        if (instancia != null && instancia != this)
        {
            Destroy(gameObject);
            return;
        }

        instancia = this;
        DontDestroyOnLoad(gameObject);
        CrearInterfaz();
    }

    public static void CargarEscena(string nombreEscena)
    {
        if (instancia == null)
        {
            SceneManager.LoadScene(nombreEscena);
            return;
        }

        if (instancia.transicionando) return;
        instancia.StartCoroutine(instancia.Transicionar(nombreEscena));
    }

    private IEnumerator Transicionar(string nombreEscena)
    {
        transicionando = true;

        // Las franjas negras cubren la pantalla una por una.
        for (int i = 0; i < franjas.Length; i++)
        {
            yield return StartCoroutine(AnimarFranja(i, 0f, 1f));
            yield return new WaitForSecondsRealtime(pausaEntreFranjas);
        }

        AsyncOperation carga = SceneManager.LoadSceneAsync(nombreEscena);

        if (carga == null)
        {
            Debug.LogError("No se pudo cargar la escena: " + nombreEscena);
            for (int i = franjas.Length - 1; i >= 0; i--)
            {
                yield return StartCoroutine(AnimarFranja(i, 1f, 0f));
            }

            transicionando = false;
            yield break;
        }

        while (!carga.isDone)
        {
            yield return null;
        }

        // Las franjas se retiran para revelar la nueva escena.
        for (int i = franjas.Length - 1; i >= 0; i--)
        {
            yield return StartCoroutine(AnimarFranja(i, 1f, 0f));
            yield return new WaitForSecondsRealtime(pausaEntreFranjas);
        }

        transicionando = false;
    }

    private IEnumerator AnimarFranja(int indice, float desde, float hasta)
    {
        float tiempo = 0f;
        float duracion = Mathf.Max(0.01f, duracionFranja);

        while (tiempo < duracion)
        {
            tiempo += Time.unscaledDeltaTime;
            float progreso = Mathf.Clamp01(tiempo / duracion);
            progreso = progreso * progreso * (3f - 2f * progreso); // SmoothStep

            franjas[indice].localScale = new Vector3(
                Mathf.Lerp(desde, hasta, progreso), 1f, 1f);

            yield return null;
        }

        franjas[indice].localScale = new Vector3(hasta, 1f, 1f);
    }

    private void CrearInterfaz()
    {
        GameObject objetoCanvas = new GameObject("CanvasTransicion");
        objetoCanvas.transform.SetParent(transform, false);

        Canvas canvas = objetoCanvas.AddComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        canvas.sortingOrder = 10000;

        CanvasScaler escalador = objetoCanvas.AddComponent<CanvasScaler>();
        escalador.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        escalador.referenceResolution = new Vector2(1920f, 1080f);
        escalador.matchWidthOrHeight = 0.5f;

        int cantidad = Mathf.Max(2, cantidadFranjas);
        franjas = new RectTransform[cantidad];

        for (int i = 0; i < cantidad; i++)
        {
            GameObject objetoFranja = new GameObject(
                "Franja_" + i, typeof(RectTransform), typeof(Image));

            RectTransform rect = objetoFranja.GetComponent<RectTransform>();
            rect.SetParent(objetoCanvas.transform, false);
            rect.anchorMin = new Vector2(0f, i / (float)cantidad);
            rect.anchorMax = new Vector2(1f, (i + 1) / (float)cantidad);
            rect.offsetMin = Vector2.zero;
            rect.offsetMax = Vector2.zero;
            rect.localScale = new Vector3(0f, 1f, 1f);

            Image imagen = objetoFranja.GetComponent<Image>();
            imagen.color = Color.black;
            imagen.raycastTarget = false;

            franjas[i] = rect;
        }
    }
}
