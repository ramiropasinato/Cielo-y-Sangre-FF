using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

[RequireComponent(typeof(AudioSource))]
public class GestorAudio : MonoBehaviour
{
    public static GestorAudio instancia;

    [Header("Músicas")]
    public AudioClip musicaMapa;
    public AudioClip musicaCombate;

    [Header("Volumen y transición")]
    [Range(0f, 1f)] public float volumen = 0.45f;
    [Min(0.01f)] public float tiempoFade = 0.8f;

    private AudioSource fuente;
    private Coroutine rutinaCambio;

    private void Awake()
    {
        if (instancia != null && instancia != this)
        {
            Destroy(gameObject);
            return;
        }

        instancia = this;
        DontDestroyOnLoad(gameObject);

        fuente = GetComponent<AudioSource>();
        fuente.playOnAwake = false;
        fuente.loop = true;
        fuente.spatialBlend = 0f; // Música 2D: no depende de la posición.
        fuente.volume = 0f;
        fuente.priority = 0;

        SceneManager.sceneLoaded += AlCargarEscena;
    }

    private void Start()
    {
        // Reproduce la música correspondiente a la escena inicial.
        ActualizarMusica(SceneManager.GetActiveScene().name);
    }

    private void OnDestroy()
    {
        if (instancia == this)
        {
            SceneManager.sceneLoaded -= AlCargarEscena;
            instancia = null;
        }
    }

    private void AlCargarEscena(Scene escena, LoadSceneMode modo)
    {
        ActualizarMusica(escena.name);
    }

    private void ActualizarMusica(string nombreEscena)
    {
        if (nombreEscena == "SampleScene")
        {
            CambiarMusica(musicaMapa);
        }
        else if (nombreEscena.StartsWith("Batalla"))
        {
            CambiarMusica(musicaCombate);
        }
        else if (nombreEscena == "Victory" || nombreEscena == "Derrota")
        {
            DetenerMusica();
        }
    }

    private void CambiarMusica(AudioClip nuevaMusica)
    {
        if (nuevaMusica == null)
        {
            Debug.LogWarning("Falta asignar una de las músicas en GestorAudio.");
            return;
        }

        if (fuente.clip == nuevaMusica && fuente.isPlaying)
        {
            return;
        }

        if (rutinaCambio != null)
        {
            StopCoroutine(rutinaCambio);
        }

        rutinaCambio = StartCoroutine(CrossFade(nuevaMusica));
    }

    private void DetenerMusica()
    {
        if (rutinaCambio != null)
        {
            StopCoroutine(rutinaCambio);
        }

        rutinaCambio = StartCoroutine(CrossFade(null));
    }

    private IEnumerator CrossFade(AudioClip nuevaMusica)
    {
        float duracionFade = Mathf.Max(0.01f, tiempoFade);

        // Baja el volumen de la canción actual.
        while (fuente.volume > 0.01f)
        {
            fuente.volume = Mathf.MoveTowards(
                fuente.volume, 0f, Time.unscaledDeltaTime / duracionFade);
            yield return null;
        }

        fuente.Stop();
        fuente.clip = nuevaMusica;

        if (nuevaMusica != null)
        {
            fuente.volume = 0f;
            fuente.Play();

            // Sube el volumen de la canción nueva.
            while (fuente.volume < volumen)
            {
                fuente.volume = Mathf.MoveTowards(
                    fuente.volume, volumen, Time.unscaledDeltaTime / duracionFade);
                yield return null;
            }
        }

        fuente.volume = nuevaMusica == null ? 0f : volumen;
        rutinaCambio = null;
    }
}
