using UnityEngine;
using TMPro;

public class SistemaDeVida : MonoBehaviour
{
    public string nombrePersonaje;
    public int hpMaximo = 50;
    public int hpActual;
    public TextMeshProUGUI textoVidaUI;

    [Header("Efecto visual al recibir daño")]
    public GameObject prefabEfectoGolpe;

    [Header("Temblor de cámara")]
    public bool temblarAlRecibirDano = true;

    private void Awake()
    {
        // Se inicializa antes de Start para que GestorDeBatalla pueda
        // aplicar después la vida guardada de Kiyomi sin que se sobrescriba.
        hpActual = hpMaximo;
        ActualizarUI();
    }

    public void RecibirDano(int cantidad)
    {
        if (cantidad <= 0 || hpActual <= 0) return;

        hpActual = Mathf.Max(0, hpActual - cantidad);

        Debug.Log(nombrePersonaje + " recibió " + cantidad +
            " de daño. HP restante: " + hpActual);

        if (temblarAlRecibirDano && Camera.main != null)
        {
            TemblorCamara temblor = Camera.main.GetComponent<TemblorCamara>();
            if (temblor != null)
            {
                temblor.Sacudir();
            }
        }

        if (prefabEfectoGolpe != null)
        {
            float offsetX = Random.Range(-0.8f, 0.8f);
            float offsetY = Random.Range(-0.8f, 0.8f);

            Vector3 posicionAleatoria = transform.position +
                new Vector3(offsetX, offsetY, 0f);

            GameObject efecto = Instantiate(
                prefabEfectoGolpe, posicionAleatoria, Quaternion.identity);

            Destroy(efecto, 0.5f);
        }

        ActualizarUI();
    }

    public void Curar(int cantidad)
    {
        if (cantidad <= 0) return;

        // Mantiene el comportamiento anterior: Curar también puede levantar
        // a un personaje que llegó a 0 HP.
        hpActual = Mathf.Min(hpActual + cantidad, hpMaximo);

        Debug.Log(nombrePersonaje + " se ha curado " + cantidad +
            " de HP. HP actual: " + hpActual);

        ActualizarUI();
    }

    public void ActualizarUI()
    {
        if (textoVidaUI != null)
        {
            textoVidaUI.text = nombrePersonaje + "\n" +
                hpActual + " / " + hpMaximo;
        }
    }
}
