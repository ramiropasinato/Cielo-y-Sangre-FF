using System.Collections;
using UnityEngine;

// Se coloca en la cámara principal de cada escena de combate.
public class TemblorCamara : MonoBehaviour
{
    [Header("Intensidad del temblor")]
    [SerializeField] private float intensidad = 0.06f;
    [SerializeField] private float duracion = 0.12f;

    private Vector3 posicionOriginal;
    private Coroutine rutinaTemblor;

    private void Awake()
    {
        posicionOriginal = transform.localPosition;
    }

    public void Sacudir()
    {
        if (rutinaTemblor != null)
        {
            StopCoroutine(rutinaTemblor);
        }

        transform.localPosition = posicionOriginal;
        rutinaTemblor = StartCoroutine(Temblar());
    }

    private IEnumerator Temblar()
    {
        float tiempo = 0f;

        while (tiempo < duracion)
        {
            Vector2 desplazamiento = Random.insideUnitCircle * intensidad;
            transform.localPosition = posicionOriginal +
                new Vector3(desplazamiento.x, desplazamiento.y, 0f);

            tiempo += Time.unscaledDeltaTime;
            yield return null;
        }

        transform.localPosition = posicionOriginal;
        rutinaTemblor = null;
    }
}
