using UnityEngine;

public class MenuPrincipal : MonoBehaviour
{
    // Conecta este método al botón JUGAR.
    public void Jugar()
    {
        TransicionRetro.CargarEscena("SampleScene");
    }

    // Conecta este método al botón SALIR.
    public void Salir()
    {
        Debug.Log("Cerrando el juego...");
        Application.Quit();
    }
}
