using UnityEngine;

public class SeguirKiyomi : MonoBehaviour
{
    public Transform kiyomi; // Acá tiene que estar asignada la Prota
    public float velocidad = 4f;
    public float distanciaParaFrenar = 1.2f;

    private Animator anim;

    void Start()
    {
        anim = GetComponent<Animator>();
        if (anim != null) anim.SetFloat("MoveY", -1f);
    }

    void FixedUpdate()
    {
        if (kiyomi != null)
        {
            float distancia = Vector2.Distance(transform.position, kiyomi.position);

            if (distancia > distanciaParaFrenar)
            {
                Vector2 direccion = (kiyomi.position - transform.position).normalized;
                transform.position = Vector2.Lerp(transform.position, kiyomi.position, velocidad * Time.fixedDeltaTime);

                if (anim != null)
                {
                    anim.SetBool("IsMoving", true);
                    anim.SetFloat("MoveX", direccion.x);
                    anim.SetFloat("MoveY", direccion.y);
                }
            }
            else
            {
                if (anim != null) anim.SetBool("IsMoving", false);
            }
        }
    }
}