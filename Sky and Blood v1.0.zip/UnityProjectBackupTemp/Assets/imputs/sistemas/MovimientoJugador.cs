using UnityEngine;
using UnityEngine.InputSystem;
using System.Collections; // Sumamos esto para poder usar tiempos y esperas

public class MovimientoJugador : MonoBehaviour
{
    [SerializeField] private float speed = 5f;
    [SerializeField] private InputActionReference moveAction;

    private Rigidbody2D rb;
    private Animator anim; // Referencia al Animator de Kiyomi

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        anim = GetComponent<Animator>();

        // Hacemos que arranque mirando hacia abajo por defecto
        if (anim != null)
        {
            anim.SetFloat("MoveY", -1f);
        }

        if (DatosGlobales.vengoDeBatalla == true)
        {
            // En vez de moverla de golpe, disparamos esta secuencia especial
            StartCoroutine(ForzarTeletransporte());
        }
    }

    IEnumerator ForzarTeletransporte()
    {
        // MAGIA: Esperamos exactamente 1 frame. 
        // Esto permite que el motor de físicas haga su carga inicial tranquilo.
        yield return null;

        // Al frame siguiente, la forzamos a ir a donde queremos
        transform.position = DatosGlobales.posicionKiyomi;
        rb.position = DatosGlobales.posicionKiyomi;

        // Apagamos la variable para que no siga teletransportándose
        DatosGlobales.vengoDeBatalla = false;
    }

    private void FixedUpdate()
    {
        // Leemos el valor del input
        Vector2 moveValue = moveAction.action.ReadValue<Vector2>();
        
        // Creamos un vector limpio para guardar la dirección final
        Vector2 direccionFinal = Vector2.zero;

        // BLOQUEO DE 4 DIRECCIONES Y CORRECCIÓN DE VELOCIDAD
        if (Mathf.Abs(moveValue.x) > 0.1f)
        {
            // Mathf.Sign devuelve 1 si es positivo o -1 si es negativo (ignora el 0.707)
            direccionFinal.x = Mathf.Sign(moveValue.x); 
        }
        else if (Mathf.Abs(moveValue.y) > 0.1f)
        {
            direccionFinal.y = Mathf.Sign(moveValue.y);
        }

        // Actualizamos las animaciones según hacia dónde se mueva
        if (anim != null)
        {
            bool seMueve = direccionFinal != Vector2.zero;
            anim.SetBool("IsMoving", seMueve);

            // Solo cambiamos MoveX y MoveY si está caminando, así al frenar sigue mirando hacia ese lado
            if (seMueve)
            {
                anim.SetFloat("MoveX", direccionFinal.x);
                anim.SetFloat("MoveY", direccionFinal.y);
            }
        }

        // Como ya forzamos a 1 o -1, sacamos el ClampMagnitude que ya no hace falta
        Vector2 movimiento = direccionFinal * speed * Time.fixedDeltaTime;

        rb.MovePosition(rb.position + movimiento);
    }
}