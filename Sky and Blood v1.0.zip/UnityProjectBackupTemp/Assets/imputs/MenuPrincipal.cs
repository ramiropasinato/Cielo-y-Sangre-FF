using UnityEngine;
using TMPro;

public class MenuPrincipal : MonoBehaviour
{
    [Header("Opciones del Menú")]
    public TextMeshProUGUI[] opciones; // 0: JUGAR, 1: CRÉDITOS, 2: SALIR
    public RectTransform barraSeleccion; // Opcional: franja detrás del texto activo

    [Header("Colores estilo Elden Ring")]
    public Color colorSeleccionado = new Color(0.95f, 0.87f, 0.65f, 1f); // Dorado claro brillante
    public Color colorNormal = new Color(0.55f, 0.55f, 0.55f, 1f);       // Gris apagado

    [Header("Panel de Créditos")]
    public GameObject panelCreditos;

    private int indiceActual = 0;
    private bool viendoCreditos = false;

    private void Start()
    {
        if (panelCreditos != null) panelCreditos.SetActive(false);
        ActualizarSeleccion();
    }

    private void Update()
    {
        if (viendoCreditos)
        {
            if (Input.GetKeyDown(KeyCode.Return) || Input.GetKeyDown(KeyCode.KeypadEnter) ||
                Input.GetKeyDown(KeyCode.Space) || Input.GetKeyDown(KeyCode.Escape))
            {
                CerrarCreditos();
            }
            return;
        }

        if (Input.GetKeyDown(KeyCode.S) || Input.GetKeyDown(KeyCode.DownArrow))
        {
            indiceActual++;
            if (indiceActual >= opciones.Length) indiceActual = 0;
            ActualizarSeleccion();
        }
        else if (Input.GetKeyDown(KeyCode.W) || Input.GetKeyDown(KeyCode.UpArrow))
        {
            indiceActual--;
            if (indiceActual < 0) indiceActual = opciones.Length - 1;
            ActualizarSeleccion();
        }

        if (Input.GetKeyDown(KeyCode.Return) || Input.GetKeyDown(KeyCode.KeypadEnter) || Input.GetKeyDown(KeyCode.Space))
        {
            if (indiceActual == 0) Jugar();
            else if (indiceActual == 1) AbrirCreditos();
            else if (indiceActual == 2) Salir();
        }
    }

    private void ActualizarSeleccion()
    {
        if (opciones == null || opciones.Length == 0) return;

        for (int i = 0; i < opciones.Length; i++)
        {
            if (opciones[i] != null)
            {
                opciones[i].color = (i == indiceActual) ? colorSeleccionado : colorNormal;
            }
        }

        if (barraSeleccion != null && opciones[indiceActual] != null)
        {
            barraSeleccion.position = new Vector3(
                barraSeleccion.position.x,
                opciones[indiceActual].rectTransform.position.y,
                barraSeleccion.position.z
            );
        }
    }

    public void Jugar()
    {
        EstadoJuego.ReiniciarPartida();
        DatosGlobales.jefeDerrotado = false;
        TransicionRetro.CargarEscena("SampleScene");
    }

    public void AbrirCreditos()
    {
        viendoCreditos = true;
        if (panelCreditos != null) panelCreditos.SetActive(true);
    }

    public void CerrarCreditos()
    {
        viendoCreditos = false;
        if (panelCreditos != null) panelCreditos.SetActive(false);
    }

    public void Salir()
    {
        Debug.Log("Saliendo del juego...");
        Application.Quit();
    }
}