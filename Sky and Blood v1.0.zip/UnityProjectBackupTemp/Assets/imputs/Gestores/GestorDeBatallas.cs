using UnityEngine;
using TMPro;
using UnityEngine.SceneManagement;
using System.Collections;

public class GestorDeBatalla : MonoBehaviour
{
    [Header("Interfaz y Textos")]
    public TextMeshProUGUI textoTurnos;

    [Header("Personajes de Batalla")]
    public SistemaDeVida scriptKiyomi;
    public SistemaDeVida scriptAliado;
    public SistemaDeVida scriptEnemigo1;
    public SistemaDeVida scriptEnemigo2;
    public SistemaDeVida scriptEnemigo3;
    public GameObject spriteAliadoBatalla;

    [Header("Animadores de Combate")]
    public Animator animKiyomi;
    public Animator animAliado;
    public Animator animEnemigo1;
    public Animator animEnemigo2;
    public Animator animEnemigo3;
    public float retrasoGolpe = 0.4f; // Tiempo entre que empieza la animación y entra el daño

    [Header("Estadísticas")]
    public int danoKiyomi = 10;
    public int danoAliado = 15;
    public int danoEnemigos = 8;
    public int curacion = 15;

    [Header("Golpes críticos")]
    [Range(0f, 1f)] public float probabilidadCritico = 0.15f;
    [Min(1f)] public float multiplicadorCritico = 2f;

    [Header("Turnos")]
    public int turnoActual = 0;
    public int enemigoSeleccionado = 0;

    private bool defiendeKiyomi = false;
    private bool defiendeAliado = false;

    private void Start()
    {
        if (scriptKiyomi != null)
        {
            scriptKiyomi.hpMaximo = EstadoJuego.vidaMaximaKiyomi;
            scriptKiyomi.hpActual = Mathf.Clamp(
                EstadoJuego.vidaActualKiyomi, 0, scriptKiyomi.hpMaximo);
            scriptKiyomi.ActualizarUI();
        }

        if (spriteAliadoBatalla != null)
        {
            spriteAliadoBatalla.SetActive(EstadoJuego.aliadoDesbloqueado);
        }

        IniciarTurnoKiyomi();
    }

    private void IniciarTurnoKiyomi()
    {
        turnoActual = 0;
        defiendeKiyomi = false;
        if (textoTurnos != null) textoTurnos.text = "Turno de Kiyomi";
    }

    private void IniciarTurnoAliado()
    {
        turnoActual = 1;
        defiendeAliado = false;
        if (textoTurnos != null) textoTurnos.text = "Turno del Aliado";
    }

    public void Atacar(int dano)
    {
        if (turnoActual != 0 && turnoActual != 1) return;

        SistemaDeVida objetivo = ObtenerEnemigoSeleccionado();

        if (objetivo == null || objetivo.hpActual <= 0)
        {
            if (textoTurnos != null) textoTurnos.text = "No hay un enemigo válido.";
            return;
        }

        StartCoroutine(SecuenciaAtaqueJugador(dano, objetivo));
    }

    private IEnumerator SecuenciaAtaqueJugador(int dano, SistemaDeVida objetivo)
    {
        int turnoQueAtaca = turnoActual;
        turnoActual = 99; // Bloquea el menú mientras dura la animación de ataque

        if (turnoQueAtaca == 0 && animKiyomi != null)
        {
            animKiyomi.SetTrigger("Atacar");
        }
        else if (turnoQueAtaca == 1 && animAliado != null)
        {
            animAliado.SetTrigger("Atacar");
        }

        yield return new WaitForSeconds(retrasoGolpe);

        if (SonidosCombate.instancia != null) SonidosCombate.instancia.ReproducirAtaque();

        int danoFinal = CalcularDano(dano, out bool esCritico);
        objetivo.RecibirDano(danoFinal);

        if (textoTurnos != null)
        {
            textoTurnos.text = esCritico
                ? "¡GOLPE CRÍTICO! " + danoFinal + " de daño"
                : "¡Ataque!";
        }

        SiguienteTurno(turnoQueAtaca);
    }

    private SistemaDeVida ObtenerEnemigoSeleccionado()
    {
        if (enemigoSeleccionado == 0) return scriptEnemigo1;
        if (enemigoSeleccionado == 1) return scriptEnemigo2;
        if (enemigoSeleccionado == 2) return scriptEnemigo3;
        return null;
    }

    private int CalcularDano(int danoBase, out bool esCritico)
    {
        esCritico = Random.value < probabilidadCritico;

        if (esCritico)
        {
            return Mathf.RoundToInt(danoBase * multiplicadorCritico);
        }

        return danoBase;
    }

    public void Defender()
    {
        if (turnoActual != 0 && turnoActual != 1) return;
        int turnoQueDefiende = turnoActual;

        if (SonidosCombate.instancia != null) SonidosCombate.instancia.ReproducirCubrirse();

        if (turnoQueDefiende == 0)
        {
            if (textoTurnos != null) textoTurnos.text = "¡Kiyomi se defiende!";
            defiendeKiyomi = true;
        }
        else if (turnoQueDefiende == 1)
        {
            if (textoTurnos != null) textoTurnos.text = "¡El Aliado se defiende!";
            defiendeAliado = true;
        }

        SiguienteTurno(turnoQueDefiende);
    }

    public void Curar()
    {
        if (turnoActual != 0 && turnoActual != 1) return;
        int turnoQueCura = turnoActual;

        if (SonidosCombate.instancia != null) SonidosCombate.instancia.ReproducirCurar();

        if (turnoQueCura == 0)
        {
            if (textoTurnos != null) textoTurnos.text = "¡Kiyomi se cura!";
            if (scriptKiyomi != null) scriptKiyomi.Curar(curacion);
        }
        else if (turnoQueCura == 1)
        {
            if (textoTurnos != null) textoTurnos.text = "¡El Aliado se cura!";
            if (scriptAliado != null) scriptAliado.Curar(curacion);
        }

        SiguienteTurno(turnoQueCura);
    }

    private void SiguienteTurno(int turnoQuePaso)
    {
        LimpiarMuertos();

        if (RevisarVictoria()) return;

        turnoActual = 99;

        if (turnoQuePaso == 0)
        {
            if (EstadoJuego.aliadoDesbloqueado &&
                scriptAliado != null && scriptAliado.hpActual > 0)
            {
                Invoke(nameof(IniciarTurnoAliado), 1f);
            }
            else
            {
                if (textoTurnos != null) textoTurnos.text = "Turno Enemigo...";
                StartCoroutine(SecuenciaAtaqueEnemigo());
            }
        }
        else if (turnoQuePaso == 1)
        {
            if (textoTurnos != null) textoTurnos.text = "Turno Enemigo...";
            StartCoroutine(SecuenciaAtaqueEnemigo());
        }
    }

    private void LimpiarMuertos()
    {
        if (scriptEnemigo1 != null && scriptEnemigo1.hpActual <= 0)
            Destroy(scriptEnemigo1.gameObject);

        if (scriptEnemigo2 != null && scriptEnemigo2.hpActual <= 0)
            Destroy(scriptEnemigo2.gameObject);

        if (scriptEnemigo3 != null && scriptEnemigo3.hpActual <= 0)
            Destroy(scriptEnemigo3.gameObject);
    }

    private IEnumerator SecuenciaAtaqueEnemigo()
    {
        yield return new WaitForSeconds(1.2f);

        // Disparamos la animación de ataque del primer enemigo que siga vivo
        if (scriptEnemigo1 != null && scriptEnemigo1.hpActual > 0)
        {
            if (animEnemigo1 != null) animEnemigo1.SetTrigger("Atacar");
        }
        else if (scriptEnemigo2 != null && scriptEnemigo2.hpActual > 0)
        {
            if (animEnemigo2 != null) animEnemigo2.SetTrigger("Atacar");
        }
        else if (scriptEnemigo3 != null && scriptEnemigo3.hpActual > 0)
        {
            if (animEnemigo3 != null) animEnemigo3.SetTrigger("Atacar");
        }

        yield return new WaitForSeconds(retrasoGolpe);

        bool hayEnemigosVivos =
            (scriptEnemigo1 != null && scriptEnemigo1.hpActual > 0) ||
            (scriptEnemigo2 != null && scriptEnemigo2.hpActual > 0) ||
            (scriptEnemigo3 != null && scriptEnemigo3.hpActual > 0);

        if (hayEnemigosVivos)
        {
            if (SonidosCombate.instancia != null) SonidosCombate.instancia.ReproducirAtaque();

            int dadoAleatorio = Random.Range(0, 2);

            if (dadoAleatorio == 1 && EstadoJuego.aliadoDesbloqueado &&
                scriptAliado != null && scriptAliado.hpActual > 0)
            {
                int danoBase = defiendeAliado ? danoEnemigos / 2 : danoEnemigos;
                int danoFinal = CalcularDano(danoBase, out bool esCritico);
                scriptAliado.RecibirDano(danoFinal);

                if (textoTurnos != null)
                {
                    textoTurnos.text = esCritico
                        ? "¡CRÍTICO al Aliado! " + danoFinal + " de daño"
                        : "¡Enemigo ataca al Aliado!";
                }
            }
            else if (scriptKiyomi != null && scriptKiyomi.hpActual > 0)
            {
                int danoBase = defiendeKiyomi ? danoEnemigos / 2 : danoEnemigos;
                int danoFinal = CalcularDano(danoBase, out bool esCritico);
                scriptKiyomi.RecibirDano(danoFinal);

                if (textoTurnos != null)
                {
                    textoTurnos.text = esCritico
                        ? "¡CRÍTICO a Kiyomi! " + danoFinal + " de daño"
                        : "¡Enemigo ataca a Kiyomi!";
                }
            }
        }

        if (scriptKiyomi != null && scriptKiyomi.hpActual > 0)
        {
            Invoke(nameof(IniciarTurnoKiyomi), 1.5f);
        }
        else
        {
            turnoActual = 4;
            if (textoTurnos != null) textoTurnos.text = "¡Kiyomi ha caído!";
            Invoke(nameof(PantallaGameOver), 2f);
        }
    }

    private bool RevisarVictoria()
    {
        bool todosMuertos =
            (scriptEnemigo1 == null || scriptEnemigo1.hpActual <= 0) &&
            (scriptEnemigo2 == null || scriptEnemigo2.hpActual <= 0) &&
            (scriptEnemigo3 == null || scriptEnemigo3.hpActual <= 0);

        if (todosMuertos)
        {
            turnoActual = 3;
            if (textoTurnos != null) textoTurnos.text = "¡Victoria!";
            Invoke(nameof(VolverAlBosque), 2f);
            return true;
        }

        return false;
    }

    private void VolverAlBosque()
    {
        if (scriptKiyomi != null)
        {
            EstadoJuego.vidaActualKiyomi = scriptKiyomi.hpActual;
        }

        string nombreEscena = SceneManager.GetActiveScene().name;
        if (nombreEscena == "BatallaFinal")
        {
            DatosGlobales.jefeDerrotado = true;
        }

        TransicionRetro.CargarEscena("SampleScene");
    }

    private void PantallaGameOver()
    {
        EstadoJuego.vidaActualKiyomi = EstadoJuego.vidaMaximaKiyomi;
        TransicionRetro.CargarEscena("Derrota");
    }
}