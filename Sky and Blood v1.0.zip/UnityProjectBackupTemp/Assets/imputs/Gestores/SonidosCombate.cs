using UnityEngine;

public class SonidosCombate : MonoBehaviour
{
    public static SonidosCombate instancia;

    [Header("Arrastrá tus archivos de audio acá")]
    public AudioClip clipAtacar;
    public AudioClip clipCubrirse;
    public AudioClip clipCurar;

    private AudioSource fuenteAudio;

    private void Awake()
    {
        instancia = this;
        fuenteAudio = GetComponent<AudioSource>();
        if (fuenteAudio == null)
        {
            fuenteAudio = gameObject.AddComponent<AudioSource>();
        }
    }

    public void ReproducirAtaque()
    {
        if (clipAtacar != null) fuenteAudio.PlayOneShot(clipAtacar);
    }

    public void ReproducirCubrirse()
    {
        if (clipCubrirse != null) fuenteAudio.PlayOneShot(clipCubrirse);
    }

    public void ReproducirCurar()
    {
        if (clipCurar != null) fuenteAudio.PlayOneShot(clipCurar);
    }
}